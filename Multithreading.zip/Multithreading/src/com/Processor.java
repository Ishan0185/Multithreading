package com;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class Processor implements Runnable {
	List<Integer> items = new ArrayList<Integer>();
	ConcurrentHashMap<Integer, AtomicInteger> chm = new ConcurrentHashMap<Integer, AtomicInteger>();
	int threadNo;
	public Processor(List<Integer> items, int threadNo) {
		this.items=items;
		this.threadNo=threadNo;
	}
	@Override
	public void run() {
//		System.out.println(items.size()+" and "+threadNo);		
		for(int index=0;index<items.size();index++) {
//			System.out.println(items.get(index)+" and "+threadNo);

			chm.put(items.get(index), new AtomicInteger(index));
		}
	}

}
