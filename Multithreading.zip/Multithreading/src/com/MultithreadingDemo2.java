package com;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MultithreadingDemo2 {
	private static final int  NUMBER_OF_THREADS =2;
	private static final int  NUMBER_OF_ITEMS =10000000;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecutorService pool = Executors.newFixedThreadPool(3); //number of concurrent threads
		List<Integer> items = new ArrayList<Integer>();
	    for(int i=0;i<NUMBER_OF_ITEMS;i++)
	    	items.add(i);
	    
	    int minItemsPerThread = NUMBER_OF_ITEMS / NUMBER_OF_THREADS;
	    int maxItemsPerThread = minItemsPerThread + 1;
	    int threadsWithMaxItems = NUMBER_OF_ITEMS - NUMBER_OF_THREADS * minItemsPerThread;
	    int start = 0;
	    long startTime = System.currentTimeMillis();
	    for (int i = 0; i < NUMBER_OF_THREADS; i++) { //Your ArrayList
	    	 int itemsCount = (i < threadsWithMaxItems ? maxItemsPerThread : minItemsPerThread);
		        int end = start + itemsCount;
		    pool.submit(new Processor(items.subList(start, end),i));
		    start = end;
		}

	    long endTime = System.currentTimeMillis();
	    System.out.println("Start :"+ startTime);
	    System.out.println("End :"+ endTime);
	    System.out.println("total :"+(endTime-startTime));
		pool.shutdown();
		try {
			pool.awaitTermination(5, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
