package com;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MultithreadingDemo {

	private static final int  NUMBER_OF_THREADS =2;
	private static final int  NUMBER_OF_ITEMS =10000000;
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub
		ExecutorService exec = Executors.newFixedThreadPool(NUMBER_OF_THREADS);
	    List<Integer> items = new ArrayList<Integer>();
	    for(int i=0;i<NUMBER_OF_ITEMS;i++)
	    	items.add(i);
	    
	    int minItemsPerThread = NUMBER_OF_ITEMS / NUMBER_OF_THREADS;
	    int maxItemsPerThread = minItemsPerThread + 1;
	    int threadsWithMaxItems = NUMBER_OF_ITEMS - NUMBER_OF_THREADS * minItemsPerThread;
	    int start = 0;
	    
	    long startTime = System.currentTimeMillis();

	    List<Future<?>> futures = new ArrayList<Future<?>>(NUMBER_OF_ITEMS);
	    for (int i = 0; i < NUMBER_OF_THREADS; i++) {
	        int itemsCount = (i < threadsWithMaxItems ? maxItemsPerThread : minItemsPerThread);
	        int end = start + itemsCount;
	        Runnable r = new Processor(items.subList(start, end),i);
	        futures.add(exec.submit(r));
	        start = end;
	    }
	    for (Future<?> f : futures) {
	        f.get();
	    }
	    
	    exec.shutdown();
	    long endTime = System.currentTimeMillis();
	    System.out.println("Start :"+ startTime);
	    System.out.println("End :"+ endTime);
	    System.out.println("total :"+(endTime-startTime));
	}

}
